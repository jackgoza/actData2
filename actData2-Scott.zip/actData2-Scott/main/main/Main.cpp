/*
Name:	Jack Goza, Joshua Ford, Scott Peery
Course:	CS303
Program:	Project 2
Due Date:

Description: 

Inputs: 

Outputs: 

Algorithm:

*****SPECIAL NOTE*****

*/